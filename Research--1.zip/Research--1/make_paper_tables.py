"""Loads the pipeline outputs (results/<dataset>/*.csv) and exposes accessors and table builders.
Every number in the manuscript comes through this module, so the paper cannot drift from the run."""
import os, math
import numpy as np, pandas as pd

RES = os.environ.get("RES", "results")
SC = ["none", "common5", "A_treated_only", "B_store_sizes", "C_gradual", "D_leak", "D2_leak_shift"]
SC_SHORT = {"none": "No shift", "common5": "5% common", "A_treated_only": "A: treated only", "B_store_sizes": "B: size per store",
            "C_gradual": "C: gradual", "D_leak": "D: leakage", "D2_leak_shift": "D2: leakage + 5%"}
SC_LONG = {"none": "No shift", "common5": "5% common shift", "A_treated_only": "A: shift in the treated store only",
           "B_store_sizes": "B: shift size differs by store", "C_gradual": "C: slow gradual shift",
           "D_leak": "D: control slightly affected by the treatment", "D2_leak_shift": "D2: leakage plus 5% common shift"}
ML = {"standard": "Standard BSTS", "bsts_control": "BSTS with control (random control)", "bsts_best_control": "BSTS with best control",
      "fixed_k": "Fixed widening (selected k)", "break_aware": "Break-aware (selected λ)", "fixed_equal_width": "Fixed widening at break-aware width",
      "conformal_scaled": "Conformal (scaled)", "conformal_abs": "Conformal (absolute)", "did_best": "DiD, best control",
      "did_random": "DiD, random control", "synthetic": "Synthetic control",
      "bsts_control_widened": "BSTS with control, widened (k)", "bsts_control_at_ba_width": "BSTS with control at break-aware width"}
ALLM = ["standard", "bsts_control", "bsts_best_control", "fixed_k", "break_aware", "fixed_equal_width", "conformal_scaled", "conformal_abs",
        "did_best", "did_random", "synthetic", "bsts_control_widened", "bsts_control_at_ba_width"]
KEYM = ["standard", "fixed_k", "break_aware", "fixed_equal_width", "did_best", "synthetic"]
NAME = {"W": "walmart", "D": "dmart"}
UNIT = {"W": 1e6, "D": 1e3}                 # report errors in millions (Walmart) / thousands (DMart)
UNITNAME = {"W": "million", "D": "thousand"}


class DS:
    def __init__(self, key):
        self.key = key; d = os.path.join(RES, NAME[key]); self.dir = d
        self.all = pd.read_csv(f"{d}/all_results.csv"); self.par = pd.read_csv(f"{d}/split_params.csv")
        self.ci = pd.read_csv(f"{d}/coverage_cis.csv"); self.std = pd.read_csv(f"{d}/standard_bsts_diagnostics.csv").set_index("scenario")
        self.ex = pd.read_csv(f"{d}/extras_bootstrap_and_pooled_width.csv"); self.det = pd.read_csv(f"{d}/table_8_7_detector_comparison.csv")
        self.pool = pd.read_csv(f"{d}/table_8_7b_pooled_controls_detection.csv"); self.power = pd.read_csv(f"{d}/table_detection_power_by_shift_size.csv")
        self.fr = pd.read_csv(f"{d}/frontier.csv"); self.we = pd.read_csv(f"{d}/worked_example.csv").iloc[0]
        self.cfg = __import__("json").load(open(f"{d}/run_config.json"))
        self.wr = pd.read_csv(f"{d}/table_width_vs_standard_mean_over_splits.csv", index_col=0)
        self.wrp = pd.read_csv(f"{d}/table_width_vs_standard_primary_split.csv", index_col=0)
        self.mae = pd.read_csv(f"{d}/table_mae_mean_over_splits.csv", index_col=0); self.bias = pd.read_csv(f"{d}/table_bias_mean_over_splits.csv", index_col=0)
        self.pc = pd.read_csv(f"{d}/table_8_8_point_correction.csv", index_col=0)
        self.diag = self.all[self.all.method == "diagnostic"].groupby("scenario")[["detect", "detect_196", "mean_abs_z", "auc_vs_none"]].mean()
        self.T0, self.H = self.cfg["T0"], self.cfg["H"]

    # ---- coverage with CI
    def _row(self, m, s, kind):
        r = self.ci[(self.ci.method == m) & (self.ci.scenario == s) & (self.ci.kind == kind)]
        return r.iloc[0]
    def cov(self, m, s, kind="pooled"): return float(self._row(m, s, kind)["cov"])
    def lo(self, m, s, kind="pooled"): return float(self._row(m, s, kind)["lo"])
    def hi(self, m, s, kind="pooled"): return float(self._row(m, s, kind)["hi"])
    def covci(self, m, s, kind="pooled", d=1):
        r = self._row(m, s, kind); return f"{r['cov']:.{d}f} [{r.lo:.{d}f}, {r.hi:.{d}f}]"
    def below(self, m, s): return int(self._row(m, s, "pooled")["splits_below_95"])
    def splitsd(self, m, s): return float(self._row(m, s, "pooled")["split_sd"])
    def width(self, m, s, kind="pooled"):
        t = self.wr if kind == "pooled" else self.wrp; return float(t.loc[ML[m].replace("λ", "lambda"), SC_SHORT_CSV[s]])
    def diff(self, s, kind="pooled", other="fixed_equal_width"):
        r = self._row(f"break_aware minus {other}", s, kind); return float(r["cov"]), float(r.lo), float(r.hi)
    def diff_str(self, s, kind="pooled", other="fixed_equal_width"):
        c, l, h = self.diff(s, kind, other)
        fm = lambda v: (f"{v:+.2f}" if abs(v) < 0.05 else f"{v:+.1f}").replace("-", "−")
        return f"{fm(c)} [{fm(l)}, {fm(h)}]"
    def neg_splits(self, s, other="fixed_equal_width"): return int(self._row(f"break_aware minus {other}", s, "pooled")["splits_below_95"])
    def excl_zero(self, kind="pooled", other="fixed_equal_width"):
        return [s for s in SC if self.hi(f"break_aware minus {other}", s, kind) < 0 or self.lo(f"break_aware minus {other}", s, kind) > 0]


SC_SHORT_CSV = {"none": "No shift", "common5": "5% common shift", "A_treated_only": "A: treated only", "B_store_sizes": "B: size per store",
                "C_gradual": "C: slow gradual", "D_leak": "D: control leakage", "D2_leak_shift": "D2: leakage + 5% shift"}
# width tables carry method labels from the pipeline (with the word lambda)
_ML_CSV = {k: v.replace("λ", "lambda") for k, v in ML.items()}
_ML_CSV["bsts_control_widened"] = "BSTS with control, widened (k on calibration)"
ML_CSV = _ML_CSV
def _w(self, m, s, kind="pooled"):
    t = self.wr if kind == "pooled" else self.wrp; return float(t.loc[ML_CSV[m], SC_SHORT_CSV[s]])
DS.width = _w

W, D = DS("W"), DS("D")
DSS = {"W": W, "D": D}


# ------------------------------------------------------------------------------------------ formatting
def f1(x): return f"{x:.1f}".replace("-", "−")
def f2(x): return f"{x:.2f}".replace("-", "−")
def pct(x, d=1): return f"{x:.{d}f}%"
def sgn(x, d=1): return f"{x:+.{d}f}".replace("-", "−")
def rng(vals, d=1, suffix=""):
    return f"{min(vals):.{d}f}{suffix} to {max(vals):.{d}f}{suffix}"


def md_table(header, rows, widths=None, align=None):
    """Pipe table. widths = relative column widths (controls pandoc's column proportions)."""
    n = len(header); widths = widths or [1] * n; tot = sum(widths)
    seps = []
    for i, w in enumerate(widths):
        dashes = "-" * max(3, int(round(60 * w / tot)))
        a = (align or ["l"] + ["r"] * (n - 1))[i]
        seps.append(dashes + (":" if a == "r" else "") if a != "c" else ":" + dashes + ":")
    out = ["| " + " | ".join(header) + " |", "|" + "|".join(seps) + "|"]
    out += ["| " + " | ".join(str(c) for c in r) + " |" for r in rows]
    return "\n".join(out)


# ------------------------------------------------------------------------------------------ tables
def t_cov_ci(key, kind="pooled", methods=KEYM):
    ds = DSS[key]; hdr = ["Scenario"] + [ML[m] for m in methods]
    rows = [[SC_SHORT[s]] + [ds.covci(m, s, kind) for m in methods] for s in SC]
    return md_table(hdr, rows, [2.2] + [2] * len(methods), ["l"] + ["c"] * len(methods))


def t_cov_all(key, kind="pooled", methods=ALLM, d=1):
    ds = DSS[key]; hdr = ["Method"] + [SC_SHORT[s] for s in SC]
    rows = [[ML[m]] + [f"{ds.cov(m, s, kind):.{d}f}" for s in SC] for m in methods]
    return md_table(hdr, rows, [4] + [1.3] * 7)


def t_width_all(key, kind="pooled", methods=ALLM):
    ds = DSS[key]; hdr = ["Method"] + [SC_SHORT[s] for s in SC]
    rows = [[ML[m]] + [f"{ds.width(m, s, kind):.2f}" for s in SC] for m in methods]
    return md_table(hdr, rows, [4] + [1.3] * 7)


def t_equal_width(key):
    ds = DSS[key]; hdr = ["Scenario", "Break-aware", "Fixed at BA width", "Difference, 20 splits [95% CI]", "Splits with a negative difference", "Difference, primary split [95% CI]"]
    rows = []
    for s in SC:
        rows.append([SC_SHORT[s], f"{ds.cov('break_aware', s):.1f}", f"{ds.cov('fixed_equal_width', s):.1f}", ds.diff_str(s), f"{ds.neg_splits(s)} of 20", ds.diff_str(s, 'primary')])
    return md_table(hdr, rows, [2, 1.3, 1.5, 2.6, 1.6, 2.6], ["l", "r", "r", "c", "c", "c"])


def t_selected(key):
    ds = DSS[key]; p = ds.par; im = ds.ex[ds.ex.kind == "implied_lambda"]
    pr = p.iloc[0]
    rows = [["Break-aware λ", f"{int(pr.lam)}", f"{p.lam.mean():.2f}", f"{int(p.lam.min())} to {int(p.lam.max())}"],
            ["Fixed multiplier k", f"{pr.k:g}", f"{p.k.mean():.2f}", f"{p.k.min():g} to {p.k.max():g}"],
            ["Detection threshold c (conformal rule)", f"{pr.thr:.2f}", f"{p.thr.mean():.2f}", f"{p.thr.min():.2f} to {p.thr.max():.2f}"],
            ["λ implied by the bias bound (Section 4.7.1)", "—", f"{im.value.mean():.2f}", f"{im.value.min():.2f} to {im.value.max():.2f}"]]
    return md_table(["Quantity", "Primary split", "Mean over 20 splits", "Range over 20 splits"], rows, [4, 1.5, 2, 2.3], ["l", "r", "r", "r"])


def t_detect(key):
    ds = DSS[key]; rows = []
    nm = {"yoy": "Year-over-year (used)", "legacy": "Trend + seasonality (alternative)"}
    rl = {"fixed 1.96": "1.96", "95% quantile (old rule)": "95% sample quantile", "conformal (n+1) rule": "Finite-sample rule"}
    for _, r in ds.det.iterrows():
        rows.append([nm[r["diagnostic"]], rl[r["threshold_rule"]], f"{r.mean_threshold:.2f}", f"{r.false_alarm_pct:.1f}%", f"{r.detection_pct_5pct_shift:.1f}% ({r.detection_sd:.1f})", f"{r.auc:.2f}"])
    return md_table(["Diagnostic", "Threshold rule", "Mean threshold", "False-alarm rate", "Detection of 5% shift (SD)", "AUC"], rows, [3, 2.4, 1.5, 1.7, 2.6, 1])


def t_power(key):
    ds = DSS[key]; rows = []
    for dg, nm in (("yoy", "Year-over-year"), ("legacy", "Trend + seasonality")):
        q = ds.power[ds.power["diagnostic"] == dg].set_index("shift_pct")["detection_pct"]
        rows.append([nm] + [f"{q[x]:.1f}%" for x in (2.0, 3.0, 5.0, 8.0, 10.0)])
    return md_table(["Diagnostic (finite-sample threshold)", "2% shift", "3% shift", "5% shift", "8% shift", "10% shift"], rows, [4, 1, 1, 1, 1, 1])


def t_pooled(key):
    ds = DSS[key]; rows = []
    for _, r in ds.pool.iterrows():
        lab = "1 (pooled-rule threshold)" if r.controls_pooled == 1 else f"{int(r.controls_pooled)}"
        rows.append([lab, f"{r.false_alarm_pct:.1f}%", f"{r.detect_2pct_shift:.1f}%", f"{r.detect_3pct_shift:.1f}%", f"{r.detect_5pct_shift:.1f}%",
                     f"{r.detect_8pct_shift:.1f}%", f"{r.detect_10pct_shift:.1f}%", f"{r.auc_5pct_shift:.2f}"])
    return md_table(["Controls pooled", "False alarms", "2% shift", "3% shift", "5% shift", "8% shift", "10% shift", "AUC (5% shift)"], rows, [2.6, 1.4, 1.1, 1.1, 1.1, 1.1, 1.1, 1.4])


def t_diag_scen(key):
    ds = DSS[key]; rows = []
    for s in SC:
        rows.append([SC_SHORT[s], f"{ds.diag.loc[s, 'mean_abs_z']:.2f}", f"{100 * ds.diag.loc[s, 'detect']:.1f}%", f"{ds.width('break_aware', s):.2f}",
                     f"{ds.cov('break_aware', s):.1f}", f"{ds.cov('fixed_equal_width', s):.1f}"])
    return md_table(["Scenario", "Mean abs. control z", "Alarm rate at calibrated threshold", "BA width (× standard)", "BA coverage (%)", "Fixed at BA width: coverage (%)"], rows, [2.4, 1.5, 2.3, 1.7, 1.5, 2.2])


def t_err(key):
    ds = DSS[key]; u = UNIT[key]; hdr = ["Method"] + [SC_SHORT[s] for s in SC]
    ml = {"standard": "Standard BSTS (also fixed, break-aware, conformal)", "bsts_control": "BSTS with control (random control)", "bsts_best_control": "BSTS with best control",
          "did_best": "DiD, best control", "did_random": "DiD, random control", "synthetic": "Synthetic control"}
    rows = []
    for m, lab in ml.items():
        r = ML_CSV[m]; rows.append([lab] + [f"{ds.bias.loc[r, SC_SHORT_CSV[s]] / u:+.2f} / {ds.mae.loc[r, SC_SHORT_CSV[s]] / u:.2f}".replace("-", "−") for s in SC])
    pc = ds.pc.reindex(SC); rows.append(["Point-estimate correction (Section 4.10)"] + [f"{pc.loc[s, 'bias'] / u:+.2f} / {pc.loc[s, 'mae'] / u:.2f}".replace("-", "−") for s in SC])
    return md_table(hdr, rows, [4] + [1.5] * 7)


def t_pc(key):
    ds = DSS[key]; u = UNIT[key]; pc = ds.pc.reindex(SC); rows = []
    for s in SC:
        rows.append([SC_SHORT[s], f"{pc.loc[s, 'pct_corrected']:.1f}%", f"{pc.loc[s, 'mae_uncorrected'] / u:.2f}", f"{pc.loc[s, 'mae'] / u:.2f} ({pc.loc[s, 'mae_change_pct']:+.1f}%)".replace("-", "−"),
                     f"{pc.loc[s, 'bias_uncorrected'] / u:+.2f} → {pc.loc[s, 'bias'] / u:+.2f}".replace("-", "−")])
    return md_table(["Scenario", "Share corrected", "MAE, standard", "MAE, corrected (change)", "Mean bias, standard → corrected"], rows, [2.4, 1.4, 1.5, 2.4, 2.8])


def t_std(key):
    ds = DSS[key]; rows = []
    for s in ("none", "common5"):
        r = ds.std.loc[s]
        rows.append([SC_SHORT[s], f"{int(r.covered_units)} of {int(r.n_units)} ({r.coverage_pct:.1f}%)", f"{r.sd_scaled_error:.2f}", f"{r.mae_over_halfwidth:.2f}", f"{100 * r.share_est_above_true:.0f}%"])
    return md_table(["Scenario", "Stores covered", "SD of error / standard error", "Mean abs. error / half-width", "Estimate above true effect"], rows, [1.6, 2.4, 2.2, 2.2, 1.9])


def t_pooled_width(key):
    ds = DSS[key]; e = ds.ex[ds.ex.kind == "pooled_equal_width"].groupby("share_shifted")[["width_vs_standard", "cov_standard", "cov_break_aware", "cov_single_fixed"]].mean()
    rows = [[f"{int(100 * p)}%", f"{r.width_vs_standard:.2f}", f"{r.cov_standard:.1f}", f"{r.cov_break_aware:.1f}", f"{r.cov_single_fixed:.1f}"] for p, r in e.iterrows()]
    return md_table(["Share of shifted pairs", "Common width (× standard)", "Standard", "Break-aware", "Single fixed multiplier"], rows, [2, 2, 1.3, 1.5, 2])


def pooled_row(key, p):
    ds = DSS[key]; e = ds.ex[ds.ex.kind == "pooled_equal_width"].groupby("share_shifted")[["width_vs_standard", "cov_break_aware", "cov_single_fixed"]].mean()
    return e.loc[p]


def frontier_stats(key, scen=("none", "common5"), rmax=25):
    """At each break-aware grid point (lambda>0, width ratio <= rmax) compare with the fixed-widening curve interpolated at the same width."""
    ds = DSS[key]; res = {}
    for sc in scen:
        f = ds.fr[ds.fr.scenario == sc].groupby(["family", "value"])[["ratio", "cov"]].mean().reset_index()
        fx = f[f.family == "fixed"].sort_values("ratio"); ba = f[(f.family == "break_aware") & (f.value > 0) & (f.ratio <= rmax)].sort_values("ratio")
        fx_at = np.interp(np.log(ba.ratio), np.log(fx.ratio), fx["cov"]); ge = int(np.sum(fx_at >= ba["cov"].to_numpy() - 1e-9))
        res[sc] = (ge, len(ba))
    return res


def width_reach(key, scen, target=95.0):
    """Smallest width ratio at which each family reaches the target mean coverage (grid points), NaN if never."""
    ds = DSS[key]; f = ds.fr[ds.fr.scenario == scen].groupby(["family", "value"])[["ratio", "cov"]].mean().reset_index(); out = {}
    for fam in ("fixed", "break_aware"):
        q = f[(f.family == fam) & (f["cov"] >= target / 100)].sort_values("ratio"); out[fam] = float(q.ratio.iloc[0]) if len(q) else float("nan")
    return out


def cross_table():
    rows = []
    for lab, fn in (("Standard BSTS, no shift", lambda k: DSS[k].cov("standard", "none")), ("Standard BSTS, 5% common shift", lambda k: DSS[k].cov("standard", "common5")),
                    ("Break-aware, 5% common shift", lambda k: DSS[k].cov("break_aware", "common5")), ("Fixed at break-aware width, 5% common shift", lambda k: DSS[k].cov("fixed_equal_width", "common5")),
                    ("Break-aware, treated-only shift (A)", lambda k: DSS[k].cov("break_aware", "A_treated_only")), ("Fixed at break-aware width, treated-only shift (A)", lambda k: DSS[k].cov("fixed_equal_width", "A_treated_only")),
                    ("DiD, best control, treated-only shift (A)", lambda k: DSS[k].cov("did_best", "A_treated_only")), ("Synthetic control, treated-only shift (A)", lambda k: DSS[k].cov("synthetic", "A_treated_only"))):
        rows.append([lab, f"{fn('W'):.1f}", f"{fn('D'):.1f}"])
    rows.append(["Break-aware minus fixed at equal width, range over 7 scenarios (pp)", rng([W.diff(s)[0] for s in SC], 1).replace("-", "−"), rng([D.diff(s)[0] for s in SC], 1).replace("-", "−")])
    rows.append(["Scenarios with 95% CI of that difference below zero", f"{len(W.excl_zero())} of 7", f"{len(D.excl_zero())} of 7"])
    rows.append(["5% shift detected, one control (finite-sample rule)", f"{100 * W.diag.loc['common5', 'detect']:.1f}%", f"{100 * D.diag.loc['common5', 'detect']:.1f}%"])
    rows.append(["5% shift detected, ten pooled controls", f"{W.pool[W.pool.controls_pooled == 10].detect_5pct_shift.iloc[0]:.1f}%", f"{D.pool[D.pool.controls_pooled == 10].detect_5pct_shift.iloc[0]:.1f}%"])
    rows.append(["False-alarm rate, ten pooled controls", f"{W.pool[W.pool.controls_pooled == 10].false_alarm_pct.iloc[0]:.1f}%", f"{D.pool[D.pool.controls_pooled == 10].false_alarm_pct.iloc[0]:.1f}%"])
    return md_table(["Quantity (mean over 20 splits unless stated)", "Walmart", "DMart panel"], rows, [6, 1.4, 1.4])


# ------------------------------------------------------------------------------------------ command line
if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "paper_tables.md"
    plan = [("8.1", "Standard BSTS diagnostics", "t_std('W')"), ("8.2", "Coverage with 95% CI, 20 splits", "t_cov_ci('W')"),
            ("8.3", "Coverage, all methods, 20 splits", "t_cov_all('W')"), ("8.4", "Width ratio, all methods, 20 splits", "t_width_all('W')"),
            ("8.5", "Coverage, all methods, primary split", "t_cov_all('W','primary')"), ("8.6", "Break-aware minus fixed at equal width", "t_equal_width('W')"),
            ("8.7", "One common width, by share shifted", "t_pooled_width('W')"), ("8.8", "Calibrated parameters and implied lambda", "t_selected('W')"),
            ("8.9", "Detector comparison", "t_detect('W')"), ("8.10", "Detection by shift size", "t_power('W')"), ("8.11", "Pooled controls", "t_pooled('W')"),
            ("8.12", "Alarm and break-aware interval by scenario", "t_diag_scen('W')"), ("8.13", "Point-estimate correction", "t_pc('W')"),
            ("8.14", "Bias / MAE by method", "t_err('W')"), ("8.15", "DMart panel: coverage with 95% CI", "t_cov_ci('D')"),
            ("8.16", "DMart panel: break-aware minus fixed at equal width", "t_equal_width('D')"), ("8.17", "DMart panel: calibrated parameters", "t_selected('D')"),
            ("8.18", "DMart panel: pooled controls", "t_pooled('D')"), ("8.19", "Key results on both panels", "cross_table()")]
    with open(out, "w", encoding="utf8") as f:
        for n, cap, call in plan:
            f.write(f"**Table {n}. {cap}**\n\n{eval(call)}\n\n")
    print("wrote", out)
